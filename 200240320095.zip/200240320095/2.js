function validation(){
let x= document.querySelector("#userName").value;
let y=document.querySelector("#pass").value;
 
 if (x=="" || y== "") {
     alert("Fill the username and password both");
     
 
 }
else
{               
                   document.querySelector("#userName").value="";
                   document.querySelector("#pass").value="";
             const newElement= document.querySelector("#sampleBox").cloneNode(true);                
             newElement.style.visibilty="visible";
             newElement.children[0].innerHTML=x;
             newElement.children[1].innerHTML=y;
            
             const info=document.querySelector("#infoBox");
             info.insertBefore(newElement,info.firstChild);
 
}

 
 

}
//  let uname= document.querySelector("#userName").value;
//let pwd=document.querySelector("#pass").value;


        